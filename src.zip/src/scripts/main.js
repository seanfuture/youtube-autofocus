$('#player embed')[0].focus();
